import pandas as pd
import numpy as np
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import classification_report, confusion_matrix
import tensorflow as tf
from tensorflow.keras.models import Sequential, Model
from tensorflow.keras.layers import *
from tensorflow.keras.callbacks import EarlyStopping, ReduceLROnPlateau
from tensorflow.keras.utils import to_categorical
import pickle
import matplotlib.pyplot as plt


class HybridPasswordClassifier:
    def __init__(self):
        self.traditional_model = None
        self.deep_model = None
        self.char_to_idx = {}
        self.idx_to_char = {}
        self.max_length = 64

    def create_char_mapping(self, passwords):
        """Create character-to-index and index-to-character mappings"""
        all_chars = set(''.join(passwords))
        all_chars.add('<PAD>')  # For padding
        all_chars.add('<UNK>')  # For unknown characters

        self.char_to_idx = {char: idx for idx, char in enumerate(sorted(all_chars))}
        self.idx_to_char = {idx: char for char, idx in self.char_to_idx.items()}

        print(f"Character vocabulary size: {len(self.char_to_idx)}")

    def encode_passwords(self, passwords):
        """Convert passwords into fixed-length numeric sequences"""
        encoded = []
        for password in passwords:
            encoded_pwd = [self.char_to_idx.get(char, self.char_to_idx['<UNK>'])
                           for char in password]

            if len(encoded_pwd) > self.max_length:
                encoded_pwd = encoded_pwd[:self.max_length]
            else:
                encoded_pwd.extend([self.char_to_idx['<PAD>']] * (self.max_length - len(encoded_pwd)))

            encoded.append(encoded_pwd)

        return np.array(encoded)

    def create_deep_model(self, vocab_size, embedding_dim=64):
        """Build the deep learning model"""
        model = Sequential([
            Embedding(vocab_size, embedding_dim, input_length=self.max_length),
            Bidirectional(LSTM(128, return_sequences=True, dropout=0.3)),
            Bidirectional(LSTM(64, dropout=0.3)),
            Dense(128, activation='relu'),
            Dropout(0.5),
            Dense(64, activation='relu'),
            Dropout(0.3),
            Dense(32, activation='relu'),
            Dense(3, activation='softmax')
        ])

        model.compile(
            optimizer='adam',
            loss='categorical_crossentropy',
            metrics=['accuracy']
        )

        print("Deep Learning Model Summary:")
        model.summary()

        return model

    def create_traditional_model(self):
        """Build the traditional ML model"""
        return RandomForestClassifier(
            n_estimators=200,
            max_depth=20,
            min_samples_split=5,
            min_samples_leaf=2,
            random_state=42,
            n_jobs=-1
        )

    def train_models(self, passwords, strengths, traditional_features):
        """Train both the traditional and deep learning models"""
        print("Training models...")

        # Split the dataset
        X_trad_train, X_trad_test, X_seq_train, X_seq_test, y_train, y_test = train_test_split(
            traditional_features,
            self.encode_passwords(passwords),
            strengths,
            test_size=0.2,
            random_state=42,
            stratify=strengths
        )

        # Train traditional model
        print("Training traditional model...")
        self.traditional_model = self.create_traditional_model()
        self.traditional_model.fit(X_trad_train, y_train)

        trad_score = self.traditional_model.score(X_trad_test, y_test)
        print(f"Traditional model accuracy: {trad_score:.3f}")

        # Train deep learning model
        print("Training deep learning model...")
        vocab_size = len(self.char_to_idx)
        self.deep_model = self.create_deep_model(vocab_size)

        y_train_cat = to_categorical(y_train, num_classes=3)
        y_test_cat = to_categorical(y_test, num_classes=3)

        callbacks = [
            EarlyStopping(patience=10, restore_best_weights=True),
            ReduceLROnPlateau(patience=5, factor=0.5)
        ]

        history = self.deep_model.fit(
            X_seq_train, y_train_cat,
            validation_data=(X_seq_test, y_test_cat),
            epochs=50,
            batch_size=512,
            callbacks=callbacks,
            verbose=1
        )

        deep_score = self.deep_model.evaluate(X_seq_test, y_test_cat, verbose=0)[1]
        print(f"Deep learning model accuracy: {deep_score:.3f}")

        # Evaluate ensemble
        print("Testing ensemble model...")
        ensemble_accuracy = self.evaluate_ensemble(X_trad_test, X_seq_test, y_test)
        print(f"Ensemble model accuracy: {ensemble_accuracy:.3f}")

        return {
            'traditional_accuracy': trad_score,
            'deep_accuracy': deep_score,
            'ensemble_accuracy': ensemble_accuracy,
            'history': history.history
        }

    def predict_single(self, password, traditional_features):
        """Predict strength of a single password using ensemble model"""
        trad_pred = self.traditional_model.predict_proba([traditional_features])[0]
        encoded_pwd = self.encode_passwords([password])
        deep_pred = self.deep_model.predict(encoded_pwd, verbose=0)[0]

        ensemble_pred = 0.6 * trad_pred + 0.4 * deep_pred
        final_prediction = np.argmax(ensemble_pred)
        confidence = np.max(ensemble_pred)

        return {
            'prediction': int(final_prediction),
            'confidence': float(confidence),
            'probabilities': {
                'weak': float(ensemble_pred[0]),
                'medium': float(ensemble_pred[1]),
                'strong': float(ensemble_pred[2])
            }
        }
