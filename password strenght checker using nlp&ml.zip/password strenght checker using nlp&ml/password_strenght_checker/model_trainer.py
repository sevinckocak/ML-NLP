import pandas as pd
import numpy as np
from sklearn.ensemble import RandomForestClassifier
from sklearn.model_selection import train_test_split
from sklearn.metrics import classification_report, accuracy_score
import pickle
from feature_engineering import PasswordFeatureEngineer


class PasswordStrengthModel:
    def __init__(self):
        self.feature_engineer = PasswordFeatureEngineer()
        self.model = RandomForestClassifier(n_estimators=100, random_state=42)
        self.is_trained = False

    def train(self, csv_file_path):
        """Train the model"""
        print("Loading data...")
        df = pd.read_csv(csv_file_path)

        # Sample a subset if the data is large
        sample_size = min(100000, len(df))
        df_sample = df.sample(n=sample_size, random_state=42)

        print("Starting feature extraction...")
        # Feature extraction
        X, feature_names = self.feature_engineer.fit_transform(df_sample['password'].tolist())
        y = df_sample['strength'].values

        # Train-test split
        X_train, X_test, y_train, y_test = train_test_split(
            X, y, test_size=0.2, random_state=42, stratify=y
        )

        print("Training the model...")
        # Train the model
        self.model.fit(X_train, y_train)

        # Evaluate the model
        y_pred = self.model.predict(X_test)
        accuracy = accuracy_score(y_test, y_pred)

        print("Model training complete.")
        print(f"Test Accuracy: {accuracy:.4f}")
        print("\nClassification Report:")
        print(classification_report(y_test, y_pred))

        self.is_trained = True
        return accuracy

    def predict_single(self, password):
        """Predict strength of a single password"""
        if not self.is_trained:
            raise ValueError("The model is not trained yet.")

        # Feature extraction
        features = self.feature_engineer.transform([password])

        # Prediction
        prediction = self.model.predict(features)[0]
        probability = self.model.predict_proba(features)[0]

        # Map strength values to labels
        strength_map = {0: 'Weak', 1: 'Medium', 2: 'Strong'}

        return {
            'strength': strength_map.get(prediction, 'Unknown'),
            'strength_score': int(prediction),
            'confidence': float(max(probability)),
            'probabilities': {
                'Weak': float(probability[0]),
                'Medium': float(probability[1]) if len(probability) > 1 else 0.0,
                'Strong': float(probability[2]) if len(probability) > 2 else 0.0
            }
        }

    def get_password_analysis(self, password):
        """Provide a detailed password analysis"""
        prediction = self.predict_single(password)

        # Additional features
        basic_features = self.feature_engineer.extract_traditional_features(password)
        nlp_features = self.feature_engineer.extract_nlp_features(password)

        analysis = {
            'prediction': prediction,
            'basic_info': {
                'length': basic_features.get('length', 0),
                'has_uppercase': bool(basic_features.get('has_upper', 0)),
                'has_lowercase': bool(basic_features.get('has_lower', 0)),
                'has_digits': bool(basic_features.get('has_digit', 0)),
                'has_special_chars': bool(basic_features.get('has_special', 0)),
                'character_variety': round(basic_features.get('char_variety', 0), 3),
                'entropy': round(nlp_features.get('entropy', 0), 3)
            },
            'suggestions': self._get_suggestions(basic_features, nlp_features)
        }

        return analysis

    def _get_suggestions(self, basic_features, nlp_features):
        """Provide suggestions for password improvement"""
        suggestions = []

        if basic_features.get('length', 0) < 8:
            suggestions.append("Password should be at least 8 characters long.")

        if not basic_features.get('has_upper', 0):
            suggestions.append("Add at least one uppercase letter.")

        if not basic_features.get('has_lower', 0):
            suggestions.append("Add at least one lowercase letter.")

        if not basic_features.get('has_digit', 0):
            suggestions.append("Include at least one digit.")

        if not basic_features.get('has_special', 0):
            suggestions.append("Include at least one special character (!@#$%^&*).")

        if basic_features.get('char_variety', 0) < 0.5:
            suggestions.append("Use a more diverse set of characters.")

        if nlp_features.get('entropy', 0) < 3.0:
            suggestions.append("Create a more complex character combination.")

        if basic_features.get('has_weak_words', 0):
            suggestions.append("Avoid using common or predictable words.")

        return suggestions

    def save_model(self, filepath):
        """Save the trained model to a file"""
        if not self.is_trained:
            raise ValueError("The model is not trained yet.")

        model_data = {
            'feature_engineer': self.feature_engineer,
            'model': self.model,
            'is_trained': self.is_trained
        }

        with open(filepath, 'wb') as f:
            pickle.dump(model_data, f)

        print(f"Model saved to: {filepath}")

    def load_model(self, filepath):
        """Load the model from a file"""
        with open(filepath, 'rb') as f:
            model_data = pickle.load(f)

        self.feature_engineer = model_data['feature_engineer']
        self.model = model_data['model']
        self.is_trained = model_data['is_trained']

        print(f"Model loaded from: {filepath}")


# Model training
if __name__ == "__main__":
    password_model = PasswordStrengthModel()

    # Path to the dataset CSV file
    csv_path = 'data_clean.csv'  # Update this path as needed

    # Train the model
    accuracy = password_model.train(csv_path)

    # Save the trained model
    password_model.save_model('password_strength_model.pkl')

