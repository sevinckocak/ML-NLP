import pandas as pd
import numpy as np
import re
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.preprocessing import StandardScaler
import pickle
from collections import Counter
import math


class PasswordFeatureEngineer:
    def __init__(self):
        self.tfidf_vectorizer = None
        self.scaler = StandardScaler()
        self.common_patterns = [
            r'\d{4,}',  # 4+ consecutive digits
            r'[a-z]{4,}',  # 4+ consecutive lowercase letters
            r'[A-Z]{4,}',  # 4+ consecutive uppercase letters
            r'(.)\1{2,}',  # Repeating characters
            r'(123|234|345|456|567|678|789|890)',  # Sequential digits
            r'(abc|bcd|cde|def|efg|fgh|ghi|hij|ijk|jkl|klm|lmn|mno|nop|opq|pqr|qrs|rst|stu|tuv|uvw|vwx|wxy|xyz)',  # Alphabet sequences
            r'(qwe|wer|ert|rty|tyu|yui|uio|iop|asd|sdf|dfg|fgh|ghj|hjk|jkl|zxc|xcv|cvb|vbn|bnm)',  # Keyboard patterns
        ]

        self.weak_words = {
            'password', 'admin', 'login', 'user', 'test', 'guest', 'root',
            'welcome', 'hello', 'world', 'love', 'family', 'home', 'work',
            'company', 'system', 'computer', 'internet', 'website', 'email'
        }

    def extract_traditional_features(self, password):
        """Extract traditional handcrafted features"""
        if not password:
            return {}

        # Basic features
        features = {
            'length': len(password),
            'has_upper': int(bool(re.search(r'[A-Z]', password))),
            'has_lower': int(bool(re.search(r'[a-z]', password))),
            'has_digit': int(bool(re.search(r'\d', password))),
            'has_special': int(bool(re.search(r'[^A-Za-z0-9]', password))),
        }

        # Advanced character analysis
        features.update({
            'char_variety': len(set(password)) / len(password),
            'unique_chars': len(set(password)),
            'digit_ratio': sum(c.isdigit() for c in password) / len(password),
            'alpha_ratio': sum(c.isalpha() for c in password) / len(password),
            'upper_ratio': sum(c.isupper() for c in password) / len(password),
            'lower_ratio': sum(c.islower() for c in password) / len(password),
            'special_ratio': sum(not c.isalnum() for c in password) / len(password),
        })

        # Pattern detection
        pattern_count = 0
        for pattern in self.common_patterns:
            if re.search(pattern, password, re.IGNORECASE):
                pattern_count += 1
        features['common_patterns'] = pattern_count

        # Weak keyword check
        features['has_weak_words'] = int(any(word in password.lower() for word in self.weak_words))

        # Character repetition analysis
        char_counts = Counter(password.lower())
        features['max_char_repeat'] = max(char_counts.values()) if char_counts else 0
        features['repeated_chars'] = sum(1 for count in char_counts.values() if count > 1)

        # Sequential character check
        consecutive_count = 0
        for i in range(len(password) - 2):
            if ord(password[i]) + 1 == ord(password[i + 1]) == ord(password[i + 2]) - 1:
                consecutive_count += 1
        features['consecutive_sequences'] = consecutive_count

        return features

    def calculate_entropy(self, password):
        """Calculate Shannon entropy"""
        if not password:
            return 0

        char_counts = Counter(password)
        length = len(password)
        entropy = 0

        for count in char_counts.values():
            probability = count / length
            entropy -= probability * math.log2(probability)

        return entropy

    def extract_nlp_features(self, password):
        """Extract NLP-based features"""
        features = {}

        # Entropy
        features['entropy'] = self.calculate_entropy(password)

        # N-gram analysis
        # Bigrams
        bigrams = [password[i:i + 2] for i in range(len(password) - 1)]
        features['unique_bigrams'] = len(set(bigrams)) / max(len(bigrams), 1)

        # Trigrams
        trigrams = [password[i:i + 3] for i in range(len(password) - 2)]
        features['unique_trigrams'] = len(set(trigrams)) / max(len(trigrams), 1)

        # Character frequency analysis
        char_freq = Counter(password.lower())
        features['most_frequent_char_ratio'] = max(char_freq.values()) / len(password) if password else 0

        # Keyboard proximity score (simple version)
        keyboard_rows = [
            'qwertyuiop',
            'asdfghjkl',
            'zxcvbnm',
            '1234567890'
        ]

        keyboard_proximity = 0
        for i in range(len(password) - 1):
            char1, char2 = password[i].lower(), password[i + 1].lower()
            for row in keyboard_rows:
                if char1 in row and char2 in row:
                    pos1, pos2 = row.find(char1), row.find(char2)
                    if abs(pos1 - pos2) <= 1:
                        keyboard_proximity += 1
                        break

        features['keyboard_proximity'] = keyboard_proximity / max(len(password) - 1, 1)

        return features

    def prepare_for_tfidf(self, passwords):
        """Prepare passwords for TF-IDF extraction"""
        return [' '.join(list(pwd)) for pwd in passwords]

    def fit_transform(self, passwords):
        """Extract and fit features on training data"""
        print("Feature extraction started...")

        traditional_features = []
        nlp_features = []

        for i, password in enumerate(passwords):
            if i % 10000 == 0:
                print(f"Progress: {i}/{len(passwords)}")

            trad_feat = self.extract_traditional_features(password)
            nlp_feat = self.extract_nlp_features(password)

            traditional_features.append(trad_feat)
            nlp_features.append(nlp_feat)

        trad_df = pd.DataFrame(traditional_features)
        nlp_df = pd.DataFrame(nlp_features)

        print("TF-IDF feature extraction started...")
        char_separated = self.prepare_for_tfidf(passwords)

        self.tfidf_vectorizer = TfidfVectorizer(
            analyzer='char',
            ngram_range=(1, 3),
            max_features=100,
            lowercase=True
        )

        tfidf_features = self.tfidf_vectorizer.fit_transform(passwords)
        tfidf_df = pd.DataFrame(
            tfidf_features.toarray(),
            columns=[f'tfidf_{i}' for i in range(tfidf_features.shape[1])]
        )

        all_features = pd.concat([trad_df, nlp_df, tfidf_df], axis=1)

        scaled_features = self.scaler.fit_transform(all_features)
        final_df = pd.DataFrame(scaled_features, columns=all_features.columns)

        print("Feature extraction completed!")
        print(f"Total number of features: {final_df.shape[1]}")
        print("Feature categories:")
        print(f"  - Traditional: {len(trad_df.columns)}")
        print(f"  - NLP: {len(nlp_df.columns)}")
        print(f"  - TF-IDF: {len(tfidf_df.columns)}")

        return final_df, all_features.columns.tolist()

    def transform(self, passwords):
        """Transform new data using the fitted model"""
        if self.tfidf_vectorizer is None:
            raise ValueError("Model is not fitted yet!")

        traditional_features = []
        nlp_features = []

        for password in passwords:
            trad_feat = self.extract_traditional_features(password)
            nlp_feat = self.extract_nlp_features(password)
            traditional_features.append(trad_feat)
            nlp_features.append(nlp_feat)

        trad_df = pd.DataFrame(traditional_features)
        nlp_df = pd.DataFrame(nlp_features)

        tfidf_features = self.tfidf_vectorizer.transform(passwords)
        tfidf_df = pd.DataFrame(
            tfidf_features.toarray(),
            columns=[f'tfidf_{i}' for i in range(tfidf_features.shape[1])]
        )

        all_features = pd.concat([trad_df, nlp_df, tfidf_df], axis=1)
        scaled_features = self.scaler.transform(all_features)

        return pd.DataFrame(scaled_features, columns=all_features.columns)

    def save_preprocessor(self, filepath):
        """Save the fitted preprocessor to disk"""
        with open(filepath, 'wb') as f:
            pickle.dump({
                'tfidf_vectorizer': self.tfidf_vectorizer,
                'scaler': self.scaler,
                'common_patterns': self.common_patterns,
                'weak_words': self.weak_words
            }, f)
        print(f"Preprocessor saved to: {filepath}")

    def load_preprocessor(self, filepath):
        """Load a preprocessor from disk"""
        with open(filepath, 'rb') as f:
            data = pickle.load(f)

        self.tfidf_vectorizer = data['tfidf_vectorizer']
        self.scaler = data['scaler']
        self.common_patterns = data['common_patterns']
        self.weak_words = data['weak_words']
        print(f"Preprocessor loaded from: {filepath}")


# Usage example
if __name__ == "__main__":
    df = pd.read_csv('data_clean.csv')

    sample_size = min(50000, len(df))
    df_sample = df.sample(n=sample_size, random_state=42)

    feature_engineer = PasswordFeatureEngineer()
    X, feature_names = feature_engineer.fit_transform(df_sample['password'].tolist())
    y = df_sample['strength'].values

    feature_engineer.save_preprocessor('password_preprocessor.pkl')

    X['strength'] = y
    X.to_csv('processed_features.csv', index=False)

    print("Feature engineering completed.")
    print("Saved files:")
    print("  - processed_features.csv")
    print("  - password_preprocessor.pkl")
