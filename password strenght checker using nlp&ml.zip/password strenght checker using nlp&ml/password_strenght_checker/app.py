import streamlit as st
import pickle
import os
from model_trainer import PasswordStrengthModel

# Page configuration
st.set_page_config(
    page_title="Password Strength Checker",
    page_icon=None,
    layout="centered"
)

# Title
st.title("Password Strength Checker")
st.write("Check the strength of your password")

# Model loading function
@st.cache_resource
def load_model():
    try:
        model = PasswordStrengthModel()
        if os.path.exists('password_strength_model.pkl'):
            model.load_model('password_strength_model.pkl')
            return model
        else:
            st.error("Model file not found! Run model_trainer.py first.")
            return None
    except Exception as e:
        st.error(f"Error occurred while loading the model: {str(e)}")
        return None

# Load model
model = load_model()

if model and model.is_trained:
    # Password input
    password = st.text_input("Enter your password:", type="password", placeholder="Type your password here...")

    # Check button
    if st.button("Check", type="primary"):
        if password:
            try:
                # Perform analysis
                result = model.get_password_analysis(password)

                # Show results
                prediction = result['prediction']
                basic_info = result['basic_info']
                suggestions = result['suggestions']

                # Color by strength level
                if prediction['strength'] == 'Güçlü':
                    st.success(f"**{prediction['strength']}** password!")
                elif prediction['strength'] == 'Orta':
                    st.warning(f"**{prediction['strength']}** password")
                else:
                    st.error(f"**{prediction['strength']}** password")

                # Confidence score
                st.write(f"**Confidence Score:** {prediction['confidence']:.1%}")

                # Basic info
                col1, col2 = st.columns(2)

                with col1:
                    st.write("**Password Features:**")
                    st.write(f"- Length: {basic_info['length']}")
                    st.write(f"- Uppercase letter: {'✓' if basic_info['has_uppercase'] else '✗'}")
                    st.write(f"- Lowercase letter: {'✓' if basic_info['has_lowercase'] else '✗'}")

                with col2:
                    st.write("**Character Diversity:**")
                    st.write(f"- Digit: {'✓' if basic_info['has_digits'] else '✗'}")
                    st.write(f"- Special character: {'✓' if basic_info['has_special_chars'] else '✗'}")
                    st.write(f"- Entropy: {basic_info['entropy']:.2f}")

                # Suggestions
                if suggestions:
                    st.write("**Improvement Suggestions:**")
                    for suggestion in suggestions:
                        st.write(f"• {suggestion}")
                else:
                    st.success("Your password is great!")

            except Exception as e:
                st.error(f"Error during analysis: {str(e)}")
        else:
            st.warning("Please enter a password!")

    # Example passwords
    st.write("---")
    st.write("**Example Passwords:**")

    examples = [
        ("123456", "Weak"),
        ("password", "Weak"),
        ("MyStr0ng!P@ss", "Strong"),
        ("qwerty123", "Weak"),
        ("C0mpl3x!P@ssw0rd#2024", "Strong")
    ]

    for pwd, expected in examples:
        if st.button(f"Test: {pwd} (Expected: {expected})", key=pwd):
            try:
                result = model.predict_single(pwd)
                if result['strength'] == 'Güçlü':
                    st.success(f"{result['strength']} - Confidence: {result['confidence']:.1%}")
                elif result['strength'] == 'Orta':
                    st.warning(f"{result['strength']} - Confidence: {result['confidence']:.1%}")
                else:
                    st.error(f"{result['strength']} - Confidence: {result['confidence']:.1%}")
            except Exception as e:
                st.error(f"Test error: {str(e)}")

else:
    st.error("Model could not be loaded or is not trained!")
    st.info("Run `model_trainer.py` first to train the model.")

# Footer
st.write("---")
st.caption("Password Strength Checker - NLP & Deep Learning")
